# Sonifyr
YouTube Music (https://music.youtube.com/) in a Capacitor Android shell.

1. Push this folder to a GitHub repo (branch `main`).
2. Run the **Build APK** workflow (or push) and download `Sonifyr-debug-apk` from the run's artifacts.
3. Install `app-debug.apk` on your phone.
