package com.github.innertube.models.bodies

//import com.github.innertube.InnerTubeContext
import com.github.innertube.models.Context
import com.github.innertube.models.YouTubeClient
import kotlinx.serialization.Serializable

@Serializable
data class BrowseBody(
    val localized: Boolean = true,
//    val context: InnerTubeContext = InnerTubeContext(),
    val context: Context = YouTubeClient.WEB_REMIX.toContext(localized = localized),
    val browseId: String,
    val params: String? = null
)
