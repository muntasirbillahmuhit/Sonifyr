package com.github.soundpod.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.github.core.ui.LocalAppearance
import com.github.soundpod.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaticScreenLayout(
    title: String,
    description: String? = null,
    onBackClick: () -> Unit,
    scrollable: Boolean = true,
    shape: Shape = MaterialTheme.shapes.extraLarge,
    backIcon: Int = R.drawable.arrow_back,
    horizontalPadding: Dp = 14.dp,
    actions: @Composable RowScope.() -> Unit = {},
    dropDownMenuContent: @Composable (ColumnScope.(dismissMenu: () -> Unit) -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val (colorPalette) = LocalAppearance.current

    StaticScreenLayout(
        title = {
            Column {
                Text(
                    text = title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (description != null) {
                    Text(
                        text = description,
                        style = MaterialTheme.typography.titleSmall,
                        color = colorPalette.text.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        onBackClick = onBackClick,
        scrollable = scrollable,
        shape = shape,
        backIcon = backIcon,
        horizontalPadding = horizontalPadding,
        actions = actions,
        dropDownMenuContent = dropDownMenuContent,
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaticScreenLayout(
    title: @Composable (() -> Unit)? = null,
    onBackClick: (() -> Unit)? = null,
    scrollable: Boolean = true,
    shape: Shape = MaterialTheme.shapes.extraLarge,
    backIcon: Int = R.drawable.arrow_back,
    horizontalPadding: Dp = 14.dp,
    actionsHorizontalPadding: Dp = 0.dp,
    actions: @Composable RowScope.() -> Unit = {},
    dropDownMenuContent: @Composable (ColumnScope.(dismissMenu: () -> Unit) -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val (colorPalette) = LocalAppearance.current
    val scrollState = rememberScrollState()
    var showDropDown by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { title?.invoke() },
                navigationIcon = {
                    if (onBackClick != null) {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                painter = painterResource(backIcon),
                                contentDescription = "Back",
                                modifier = Modifier.size(18.dp),
                                tint = colorPalette.text
                            )
                        }
                    }
                },
                actions = {
                    Row(
                        modifier = Modifier.padding(horizontal = actionsHorizontalPadding),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        actions()

                        if (dropDownMenuContent != null) {
                            Box(contentAlignment = Alignment.TopEnd) {
                                IconButton(onClick = { showDropDown = true }) {
                                    Icon(
                                        imageVector = Icons.Default.MoreVert,
                                        contentDescription = "More Options",
                                        tint = colorPalette.text,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                CustomDropdownMenu(
                                    expanded = showDropDown,
                                    onDismissRequest = { showDropDown = false }
                                ) {
                                    dropDownMenuContent { showDropDown = false }
                                }
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = colorPalette.text
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding()
                )

                .padding(horizontal = horizontalPadding)
                .clip(shape)
                .then(if (scrollable) Modifier.verticalScroll(scrollState) else Modifier)
        ) {
            content()
        }
    }
}
